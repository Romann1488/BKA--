# BKA-mod
Code and mod for People Playground
To download mod, tou have to tap on Green Code button. 
Button --> Download ZIP -->
drop the folder from zip, to "mod" folder, of your PPG

You can also read the code in "all.cs" file.

And belive me, it is not virus :)
